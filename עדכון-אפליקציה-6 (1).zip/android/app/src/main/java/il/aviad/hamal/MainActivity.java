package il.aviad.hamal;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;
import com.getcapacitor.JSObject;

import org.json.JSONObject;

/**
 * המסך הראשי: טוען את האתר של חמ"ל אביעד (Capacitor).
 * תוספות: לחצן ווליום כ"לחץ ודבר", פתיחה מהתראה לכתובת הנכונה,
 * והאפליקציה ממשיכה לרוץ ברקע (מיקום, קשר) כל עוד השירות פעיל.
 */
public class MainActivity extends BridgeActivity {
    /** "off" / "down" / "up" — איזה לחצן ווליום משמש ללחץ-ודבר. נקבע מה-JS */
    static volatile String pttKey = "off";
    static volatile boolean visible = false;
    private boolean pttHeld = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(HamalPlugin.class);
        super.onCreate(savedInstanceState);
        // הצבעים והמסך המלא האחרונים, כבר בפתיחה (בלי הבהוב לבן)
        try {
            SharedPreferences p = getSharedPreferences("hamal_bars", MODE_PRIVATE);
            applyBars(this, p.getString("top", "#1f2a17"), p.getString("bottom", "#f4f3ee"),
                    p.getBoolean("lightTop", false), p.getBoolean("lightBottom", true), p.getBoolean("full", false));
        } catch (Exception ignored) { }
        handleIntent(getIntent());
        // מקלדת: באנדרואיד 15 ומעלה החלון לא מתכווץ לבד, אז מרימים את התוכן בגובה המקלדת (שורת הכתיבה בצ'אט נשארת גלויה)
        if (Build.VERSION.SDK_INT >= 30) {
            final View content = findViewById(android.R.id.content);
            if (content != null) content.setOnApplyWindowInsetsListener((v, ins) -> {
                int ime = ins.getInsets(WindowInsets.Type.ime()).bottom;
                int bars = ins.getInsets(WindowInsets.Type.systemBars()).bottom;
                // אם החלון כבר התכווץ (מכשירים ישנים), המקלדת לא מגיעה לכאן כ-inset ולכן לא מרימים פעמיים
                int pad = ins.isVisible(WindowInsets.Type.ime()) ? Math.max(0, ime - (fullScreen ? 0 : bars)) : 0;
                if (v.getPaddingBottom() != pad) v.setPadding(0, 0, 0, pad);
                return v.onApplyWindowInsets(ins);
            });
        }
    }

    /** כפתור חזור: האפליקציה מחליטה (סוגרת חלון / חוזרת מסך). רק בדף הבית - יוצאים לרקע בלי לסגור */
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        try {
            final WebView wv = getBridge().getWebView();
            wv.evaluateJavascript("(function(){try{return window.hamalBack?!!window.hamalBack():null}catch(e){return null}})()", r -> {
                if ("true".equals(r)) return;
                if ("null".equals(r) && wv.canGoBack()) { wv.goBack(); return; }
                moveTaskToBack(true);
            });
        } catch (Exception e) { moveTaskToBack(true); }
    }

    static volatile boolean fullScreen = false;

    @SuppressWarnings("deprecation")
    static void applyBars(Activity a, String topHex, String bottomHex, boolean lightTop, boolean lightBottom, boolean full) {
        int top = Color.parseColor(topHex), bottom = Color.parseColor(bottomHex);
        Window w = a.getWindow();
        fullScreen = full;
        w.setStatusBarColor(top);
        w.setNavigationBarColor(bottom);
        View decor = w.getDecorView();
        // מאחורי השורות השקופות (אנדרואיד 15): למעלה צבע הכותרת, למטה צבע הסרגל
        int sb = 0;
        int id = a.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (id > 0) sb = a.getResources().getDimensionPixelSize(id);
        LayerDrawable bg = new LayerDrawable(new Drawable[]{new ColorDrawable(bottom), new ColorDrawable(top)});
        bg.setLayerGravity(1, Gravity.TOP | Gravity.FILL_HORIZONTAL);
        bg.setLayerHeight(1, Math.max(sb, 1));
        decor.setBackground(bg);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.setSystemBarsAppearance((lightTop ? WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS : 0)
                                | (lightBottom ? WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS : 0),
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
                if (full) {
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    c.hide(WindowInsets.Type.systemBars());
                } else c.show(WindowInsets.Type.systemBars());
            }
        } else {
            int f = 0;
            if (lightTop) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (lightBottom && Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            if (full) f |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            decor.setSystemUiVisibility(f);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && fullScreen) {
            try {
                SharedPreferences p = getSharedPreferences("hamal_bars", MODE_PRIVATE);
                applyBars(this, p.getString("top", "#1f2a17"), p.getString("bottom", "#f4f3ee"),
                        p.getBoolean("lightTop", false), p.getBoolean("lightBottom", true), true);
            } catch (Exception ignored) { }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        boolean alarm = intent.getBooleanExtra("alarm", false);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(alarm);
            setTurnScreenOn(alarm);
        }
        final String url = intent.getStringExtra("url");
        if (url != null && url.startsWith("https://")) {
            try {
                // קישור מהתראה: אם הוא מהכתובת הישנה או החדשה, פותחים את אותו מסך בכתובת של האפליקציה
                android.net.Uri u = android.net.Uri.parse(url);
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.endsWith(".netlify.app") || host.endsWith(".pages.dev") || host.equals(android.net.Uri.parse(getBridge().getServerUrl()).getHost())) {
                    String rest = (u.getEncodedPath() == null ? "/" : u.getEncodedPath())
                            + (u.getEncodedQuery() == null ? "" : "?" + u.getEncodedQuery())
                            + (u.getEncodedFragment() == null ? "" : "#" + u.getEncodedFragment());
                    final String target = getBridge().getServerUrl().replaceAll("/+$", "") + rest;
                    final WebView wv = getBridge().getWebView();
                    wv.postDelayed(() -> wv.evaluateJavascript("try{location.href=" + JSONObject.quote(target) + "}catch(e){}", null), 600);
                }
            } catch (Exception ignored) { }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        visible = true;
        HamalService.stopAlarm();
        HamalService.cancelAlarmNotifs(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        visible = false;
        // ממשיכים להריץ את האפליקציה ברקע: מיקום באירוע / ביציאה לשטח, קשר וכו'
        try {
            WebView wv = getBridge().getWebView();
            wv.onResume();
            wv.resumeTimers();
        } catch (Exception ignored) { }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int kc = e.getKeyCode();
        String k = pttKey;
        boolean match = ("down".equals(k) && kc == KeyEvent.KEYCODE_VOLUME_DOWN)
                || ("up".equals(k) && kc == KeyEvent.KEYCODE_VOLUME_UP)
                || (!"off".equals(k) && kc == KeyEvent.KEYCODE_HEADSETHOOK);
        if (match) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0 && !pttHeld) {
                pttHeld = true;
                JSObject d = new JSObject();
                d.put("down", true);
                HamalPlugin.emit("ptt", d);
            } else if (e.getAction() == KeyEvent.ACTION_UP && pttHeld) {
                pttHeld = false;
                JSObject d = new JSObject();
                d.put("down", false);
                HamalPlugin.emit("ptt", d);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
